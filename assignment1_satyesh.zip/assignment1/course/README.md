For the courses, the menu defines the work done.
For altering the courses, participants and other options, choose the "Select Course" menu.
The values of mobile no. and email are in String and its the user discretion to enter the correct value.
Enter the dates in dd-mm-yyyy format.
All data is being saved in a file called Course file.ser
Saved is done by selecting from the menu.
On exit data is being saved automatically.
To read from previous saved data, enter 1 at the beginning when command prompts. 
