For the contacts assignment, all options appear in the menu.
Details of the contacts can be seen on searching for a particular contact.
The birthdays and meeting dates have been taken as date in dd-mm-yyyy format.
So user must enter appropriate values.
All data is being saved in the four files respectively for the four acquaintances.
Saved is done by selecting from the menu.
On exit, data is being saved automatically.
To read from previous saved data, enter 1 at the beginning when command prompts.
